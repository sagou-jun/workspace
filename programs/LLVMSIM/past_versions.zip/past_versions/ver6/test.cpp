#include<iostream>

using namespace std;

int main(){
  cout<<"test"<<endl;
  return 0;
}
