#include"IRSim7.hpp"
#include"shim_parse_2.hxx"

using namespace IRSIM;

IRSim::IRSim(){
  PC = 0;
  option = 's';
}
void IRSim::AllocateGlobalVariables(){
  Module *Mod = Owner.get();
  Module::GlobalListType &ListOfGlobal = Mod->getGlobalList();
  cerr<<"GlobalList size ="<<ListOfGlobal.size()<<endl;
  int count = 0;
  for(Module::global_iterator GI = Mod->global_begin(),GIEnd = Mod->global_end();
      GI != GIEnd;
      GI++)
    {
      cerr<<"Operand Num ="<<GI->getNumOperands()<<endl;
      Value *GV;
      if(GI->getNumOperands() != 0)
	GV = GI->getOperand(0);
      else /*�|�C���^�^�̃O���[�o���ϐ���NumOperand��0�̏ꍇ������D���̏ꍇ�͏�̕��@�ł�Value���擾�ł��Ȃ�*/
	GV = Mod->getGlobalVariable(GI->getName());
      cerr<<count++<<":"<<GI->getName().str()<<endl;
      switch(GV->getType()->getTypeID()){
      case Type::IntegerTyID:
	{
	  ConstantInt *CI = dyn_cast<ConstantInt>(GV);
	  RegT.setRegAdd(Mem.myAllocInt(CI->getSExtValue()),GI->getName().str());
	  break;
	}
      case Type::DoubleTyID:
     	{
	  ConstantFP *CF = dyn_cast<ConstantFP>(GV);
	  RegT.setRegAdd(Mem.myAllocDouble(CF->getValueAPF().convertToDouble()),GI->getName().str());
	  break;
	}
      case Type::FloatTyID:
	{
	  ConstantFP *CF = dyn_cast<ConstantFP>(GV);
	  RegT.setRegAdd(Mem.myAllocDouble(CF->getValueAPF().convertToFloat()),GI->getName().str());
	  break;
	}
      case Type::ArrayTyID:
	{
	  ArrayType *AT = dyn_cast<ArrayType>(GV->getType());
	  RegT.setRegAdd(Mem.myAllocArray(AT),GI->getName().str())->setKind(ARRAY);
	  break;
	}
      case Type::StructTyID:
	{
	  StructType *ST = dyn_cast<StructType>(GV->getType());
	  RegT.setRegAdd(Mem.myAllocStruct(ST),GI->getName().str())->setKind(STRUCT);
	  break;
	}
      case Type::PointerTyID:
	{
	  //�|�C���^���w���Ă��郌�W�X�^�̎擾
	  cerr<<"PointerType"<<endl;
	  RegTableELE *reg;
	  if(GI->getNumOperands() != 0)
	    reg = RegT.RegLookUp(GI->getOperand(0)->getName().str());
	  else
	    reg = RegT.setRegAdd(0,GV->getName().str());
	  RegT.setRegAdd(reg->getAdd(),GI->getName().str())->setKind(POINTER);
	  break;
	}
      default:
	cerr<<"IRSim::AllocateGlobalVariables>>Undefined Types"<<endl;
	GV->dump();
      }
    }
  RegT.dump();
  return ;
}

IRSim::~IRSim(){
}

string IRSIM::RegNameGen(){
  static int RegNo = 0;
  std::ostringstream oss;
  oss<<"reg"<<RegNo;
  RegNo++;
  //fprintf(stderr,"RegNameGen generate %s\n",oss.str().c_str());
  return oss.str();
}

void IRSim::dump(){
  if(FunctionStack.size() > 1)
    FunctionStack.dump();
  RegT.dump();
  Mem.dump();
  Performance.dump();
}

bool IRSim::MemDataInport(string &RegName,double Data,unsigned offset)
{
  cerr<<"IRSim::MemDataInport "<<RegName<<" "<<offset<<" "<<Data<<endl;
  RegTableELE *reg = RegT.RegLookUp(RegName);
  if(reg != NULL&&Mem.getPtr(reg->getAdd()) != NULL)
    {
      Mem.getPtr(reg->getAdd()+offset)->setData(Data);
      return true;
    }
  cerr<<"IRSim::MemDataInport Error"<<endl;
  return false;
}

bool IRSim::MemDataExport(string &RegName,double &Data,unsigned offset)
{
  cerr<<"IRSim::MemDataExport "<<RegName<<" "<<offset<<" ";
  RegTableELE *reg = RegT.RegLookUp(RegName);
  if(reg != NULL&&Mem.getPtr(reg->getAdd()) != NULL)
    {
      Data = Mem.getPtr(reg->getAdd()+offset)->getDouble();
      cerr<<"Data="<<Data<<endl;
      return true;
    }
  cerr<<"IRSim::MemDataExport Error"<<endl;
  return false;
}

/*���̃v���O�����ƃR���p�C���I�v�V�������قȂ邽�߁C���̃t�@�C���ȊO��shim_parse_2.hxx���C���N���[�h���������Ȃ�*/

static SHIM_PARSE::shim_parse *SHIM_PARSE_OBJ = NULL;

void IRSim::Init_SHIM_PARSER(string ShimXmlFileName){
  static SHIM_PARSE::shim_parse shim(ShimXmlFileName);
  SHIM_PARSE_OBJ = &shim;
}

bool IRSim::GetBestLatency(BasicBlock *BB){
  if(SHIM_PARSE_OBJ == NULL)
    {
      return false;
    }
  double BasicBlockBest = 0;
  for(BasicBlock::iterator InstI = BB->begin(),InstI_End = BB->end();
      InstI != InstI_End;
      InstI++)
    {
      BasicBlockBest += SHIM_PARSE_OBJ->get_latency(InstI->getOpcodeName(),BEST,"\0");
    }
  Performance.BestLatency.setLatency(BB->getParent()->getName().str(),BB->getName().str(),BasicBlockBest);
  return true;
}

bool IRSim::GetWorstLatency(BasicBlock *BB){
  if(SHIM_PARSE_OBJ == NULL)
    {
      return false;
    }
  double BasicBlockBest = 0;
  for(BasicBlock::iterator InstI = BB->begin(),InstI_End = BB->end();
      InstI != InstI_End;
      InstI++)
    {
      BasicBlockBest += SHIM_PARSE_OBJ->get_latency(InstI->getOpcodeName(),WORST,"\0");
    }
  Performance.WorstLatency.setLatency(BB->getParent()->getName().str(),BB->getName().str(),BasicBlockBest);
  return true;
}
