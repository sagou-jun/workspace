#include"IRSimKinds.hpp"

using namespace IRSIM;

template<>
void Stack<StackELE>::dump(){
  int stacksize = stack.size();
  cerr<<"Stack dump (size = "<<stacksize<<")"<<endl;
  for(deque<StackELE *>::const_iterator Ite = stack.begin(),IteEnd = stack.end();
      Ite != IteEnd;
      Ite++)
    {
      cerr<<stacksize--<<":";
      (*Ite)->dump();
    }
}

template<>
void Stack<StackELE>::push(){
  StackELE *NewObj = new StackELE();
  push(NewObj);
}

StackELE *IRSIM::GetStackELEInstance(Function *Fn,unsigned RegID){
  return new StackELE(Fn,RegID);
}

std::ostream &IRSIM::operator<<(std::ostream &out,const RunInstResult &target){
  switch(target.Result)
    {
    case ERROR_RUNINST:
      out<<"ERROR_RUNINST";
      break;
    case NORMAL_RUNINST:
      out<<"NORMAL_RUNINST";
      break;
    case BRANCH_RUNINST:
      out<<"BRANCH_RUNINST";
      break;
    case FUNCTION_RUNINST:
      out<<"FUNCTION_RUNINST";
      break;
    case RETURN_RUNINST:
      out<<"RETURN_RUNINST";
      break;
    case EXIT_RUNINST:
      out<<"EXIT_RUNINST";
      break;
    }
  return out;
}

void BBCoverage::Update(string BBName){
  iterator I = BBCov.find(BBName);
  if(I == BBCov.end())
    {
      BBCov.insert(make_pair(BBName,1));
    }
  else
    I->second++;
}

void FnCoverage::setFnCov(const string FnName){
  iterator FnI = FnCov.find(FnName);
  if(FnI == FnCov.end())
    FnCov.insert(make_pair(FnName,1));
  else
    FnI->second++;
}

void FnCoverage::setBBCov(const string FnName,const string BBName){
  //cerr<<"FnName="<<FnName<<":BBName="<<BBName<<endl;
  iterator FnI = FnCov.find(FnName);
  if(FnI == FnCov.end())
    {
      cerr<<"FnCoverage::setBBCov error"<<endl;
      exit(1);
    }
  CoverageKey Key = {FnName,FnI->second};
  PtrMap<CoverageKey,BBCoverage>::iterator BBI = BBCov.find(Key);
  if(BBI == BBCov.end())
    {
      BBCoverage *NewData = new BBCoverage;
      NewData->Update(BBName);
      BBCov.insert(make_pair(Key,NewData));
    }
  else
    BBI->second->Update(BBName);
}

void FnCoverage::dump(){
  cerr<<"Coverage"<<endl;
  for( PtrMap<CoverageKey,BBCoverage>::iterator BBI = BBCov.begin(),BBEND = BBCov.end();
       BBI != BBEND;
       BBI++)
    {
      CoverageKey temp = BBI->first;
      cerr<<temp.Name<<":"<<temp.NumOfExe<<endl;
      BBI->second->dump();
    }
}

void BBCoverage::dump(){
  for(iterator I = begin(),END = end();
      I != END;
      I++)
    cerr<<"\t"<<I->first<<":"<<I->second<<endl;
}

void BBLatency::setLatency(string BBName,double latency){
  Latency[BBName] = latency;
}

bool BBLatency::hasLatency(string BBName){
  return Latency.find(BBName) != Latency.end();
}

void FnLatency::setLatency(string FnName,string BBName,double latency){
  PtrMap<string,BBLatency>::iterator I = Latency.find(FnName);
  BBLatency *NewData = new BBLatency;
  NewData->setLatency(BBName,latency); 
  if(I == Latency.end())
    Latency.insert(make_pair(FnName,NewData));
  else
    Latency.find(FnName)->second->setLatency(BBName,latency); 
}

bool FnLatency::hasLatency(string FnName,string BBName){
  PtrMap<string,BBLatency>::iterator I = Latency.find(FnName);
  if(I == Latency.end())
    return false;
  else
    return (*I).second->hasLatency(BBName);
}

void BBLatency::dump(){
  for(BBLatency::const_iterator I = const_begin(),I_END = const_end();
      I != I_END;
      I++)
    cerr<<I->first<<" "<<I->second<<endl;
}

void FnLatency::dump(){
  cerr<<"Latency"<<endl;
  for(FnLatency::const_iterator I = const_begin(),I_END = const_end();
      I != I_END;
      I++)
    {
      cerr<<I->first<<endl;
      I->second->dump();
    }
}
