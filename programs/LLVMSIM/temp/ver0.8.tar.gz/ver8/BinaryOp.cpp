#include"BinaryOp.hpp"

using namespace IRSIM;

unique_ptr<IMAWB>BinaryOpExecute::Execute(){
  unsigned opcode = _Inst->getOpcode();
  IDecodeValue *dst  =	Operands[0];
  IDecodeValue *opr1 =	Operands[1];
  IDecodeValue *opr2 =	Operands[2];
  IMAWB *NewMAWB;
  switch(opcode){
  case Instruction::Add:
    NewMAWB = new BinaryOpMAWB<int>((opr1->getInt()+opr2->getInt()),dst->getName());
    break;
  case Instruction::Sub:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()-opr2->getInt(),dst->getName());
    break;
  case Instruction::Mul:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()*opr2->getInt(),dst->getName());
    break;
  case Instruction::UDiv:
    NewMAWB = new BinaryOpMAWB<unsigned>(abs(opr1->getInt()/opr2->getInt()),dst->getName());
    break;
  case Instruction::URem:
    NewMAWB = new BinaryOpMAWB<unsigned>(abs(opr1->getInt()%opr2->getInt()),dst->getName());
    break;
  case Instruction::SDiv:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()/opr2->getInt(),dst->getName());
    break;
  case Instruction::SRem:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()%opr2->getInt(),dst->getName());
    break;
  case Instruction::FAdd:
    NewMAWB = new BinaryOpMAWB<double>(opr1->getDouble()+opr2->getDouble(),dst->getName());
    break;
  case Instruction::FSub:
    NewMAWB = new BinaryOpMAWB<double>(opr1->getDouble()-opr2->getDouble(),dst->getName());
    break;
  case Instruction::FMul:
    NewMAWB = new BinaryOpMAWB<double>(opr1->getDouble()*opr2->getDouble(),dst->getName());
    break;
  case Instruction::FDiv:
    NewMAWB = new BinaryOpMAWB<double>(opr1->getDouble()/opr2->getDouble(),dst->getName());
    break;
  case Instruction::FRem:
    NewMAWB = new BinaryOpMAWB<double>(fmod(opr1->getDouble(),opr2->getDouble()),dst->getName());
    break;
  case Instruction::Shl://shift left logical
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()<<opr2->getInt(),dst->getName());
    break;
  case Instruction::LShr://shift right logical
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()>>opr2->getInt(),dst->getName());
    break;
  case Instruction::AShr://shift right Arithmetic
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()<<opr2->getInt(),dst->getName());
    break;
  case Instruction::And:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()&opr2->getInt(),dst->getName());
    break;
  case Instruction::Or:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()|opr2->getInt(),dst->getName());
    break;
  case Instruction::Xor:
    NewMAWB = new BinaryOpMAWB<int>(opr1->getInt()^opr2->getInt(),dst->getName());
    break;
  }
  unique_ptr<IMAWB> rtn(NewMAWB);
  return rtn;
}

template<>
RunInstResult BinaryOpMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegInt(WBValue,WBRegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult BinaryOpMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegDouble(WBValue,WBRegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult BinaryOpMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegAdd(WBValue,WBRegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}
