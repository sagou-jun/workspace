#ifndef BINARYOP_H
#define BINARYOP_H

#include"IRSimExe.hpp"
#include"IRSimMems.hpp"
#include"IRSimRegs.hpp"

namespace IRSIM{
  class BinaryOpExecute:public Execution{
  private:
    BinaryOperator *_Inst;
    BinaryOpExecute(const BinaryOpExecute &obj);
    operator=(const BinaryOpExecute &obj);
  public:
    BinaryOpExecute(BinaryOperator *Inst):_Inst(Inst){};
    ~BinaryOpExecute(){};
    unique_ptr<IMAWB>Execute();
  };

  template<typename t>
  class BinaryOpMAWB:public IMAWB{
  private:
    string WBRegisterName;
    t WBValue;
    BinaryOpMAWB(const BinaryOpMAWB &obj);
    operator=(const BinaryOpMAWB &obj);
  public:
    BinaryOpMAWB(t value,string RegisterName):WBValue(value),WBRegisterName(RegisterName){};
    ~BinaryOpMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem){};
  };
  
  template<>
  RunInstResult BinaryOpMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult BinaryOpMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult BinaryOpMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem);
}

#endif
