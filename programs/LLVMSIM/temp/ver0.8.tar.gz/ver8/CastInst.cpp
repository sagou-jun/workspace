#include "CastInst.hpp"

using namespace IRSIM;

unique_ptr<IMAWB> CastInstExecute::Execute(){
  IMAWB *NewMAWB;
  switch(Operands[0]->getType().getTypeID()){
  case IRSimTypes::INTEGER:
  case IRSimTypes::CHAR:
    {
      switch(Operands[1]->getType().getTypeID()){
      case IRSimTypes::INTEGER:
      case IRSimTypes::CHAR:
	{
	  NewMAWB = new CastInstWriteBack<int>(Operands[0]->getName(),Operands[1]->getInt());
	  break;
	}
      case IRSimTypes::DOUBLE:
	{
	  NewMAWB = new CastInstWriteBack<int>(Operands[0]->getName(),Operands[1]->getDouble());
	  break;
	}
      default:
	{
	  cerr<<"CastInstExecute::Execute does not Implemente"<<endl;
	  NewMAWB = new ErrorExit();
	  break;
	}
      }
      break;
    }
  case IRSimTypes::DOUBLE:
    {
      switch(Operands[1]->getType().getTypeID()){
      case IRSimTypes::INTEGER:
      case IRSimTypes::CHAR:
	{
	  NewMAWB = new CastInstWriteBack<double>(Operands[0]->getName(),Operands[1]->getInt());
	  break;
	}
      default:
	{
	  cerr<<"CastInstExecute::Execute does not Implemente"<<endl;
	  NewMAWB = new ErrorExit();
	  break;
	}
      }
      break;
    }
  default:
    {
	cerr<<"CastInstExecute::Execute error This Type has not defined"<<endl;
	exit(1);
    }
  }
  unique_ptr<IMAWB> rtn(NewMAWB);
  return rtn;
}

template<>
RunInstResult CastInstWriteBack<int>::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegInt(_Value,WBRegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult CastInstWriteBack<double>::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegDouble(_Value,WBRegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

