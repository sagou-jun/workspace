#ifndef CASTINST_H
#define CASTINST_H

#include"IRSimExe.hpp"
#include"IRSimMems.hpp"
#include"IRSimRegs.hpp"

namespace IRSIM{

  class CastInstExecute:public Execution{
  private:
    CastInst *_CastInst;
    CastInstExecute(const CastInstExecute &obj);
    operator=(const CastInstExecute &obj);
  public:
    CastInstExecute(CastInst *Inst):_CastInst(Inst){};
    ~CastInstExecute(){};
    unique_ptr<IMAWB>Execute();
  };

  template<typename t>
  class CastInstWriteBack:public IMAWB{
  private:
    string WBRegisterName;
    t _Value;
    CastInstWriteBack(const CastInstWriteBack &obj);
    operator=(const CastInstWriteBack &obj);
  public:
    CastInstWriteBack(string RegisterName,t value):WBRegisterName(RegisterName),_Value(value){};
    ~CastInstWriteBack(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };

  template<>
  RunInstResult CastInstWriteBack<int>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult CastInstWriteBack<double>::Execute(RegTable *RegT,SIMMem *Mem);
};
#endif
