#include"CmpInst.hpp"

using namespace IRSIM;

unique_ptr<IMAWB>ICmpExecute::Execute(){
  int result;
  IDecodeValue *dst = Operands[0];
  IDecodeValue *opr1 = Operands[1], *opr2 = Operands[2];
  int unsignedopr[2] = {abs(opr1->getInt()),abs(opr2->getInt())};
  switch(_ICmpInst->getPredicate()){
  case CmpInst::ICMP_EQ:	//< equal
    {
      //cout<<" EQ ";
      if(opr1->getInt() == opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_NE:	//< not equal
    {
      //cout<<" NEQ ";
      if(opr1->getInt() != opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_UGT:	//< unsigned greater than
    {
      //cout<<" UGT ";
      if(unsignedopr[0] > unsignedopr[1])
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_UGE:	//< unsigned greater or equal
    {
      //cout<<" UGE ";
      if(unsignedopr[0] >= unsignedopr[1])
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_ULT:	//< unsigned less than
    {
      //cout<<" ULT ";
      if(unsignedopr[0] < unsignedopr[1])
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_ULE:	//< unsigned less or equal
    {
      //cout<<" ULE ";
      if(unsignedopr[0] <= unsignedopr[1])
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_SGT:	//< signed greater than
    {
      //cout<<" SGT ";
      if(opr1->getInt() > opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_SGE:	//< signed greater or equal
    {
      //cout<<" SGE ";
      if(opr1->getInt() >= opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_SLT:	//< signed less than
    {
      //cout<<" SLT ";
      if(opr1->getInt() < opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  case CmpInst::ICMP_SLE:	//< signed less or equal
    {
      //cout<<" SLE ";
      if(opr1->getInt() <= opr2->getInt())
	result = 1;
      else
	result = 0;
      break;
    }
  }
  unique_ptr<IMAWB> rtn(new CmpMAWB(result,dst->getName()));
  return rtn;
} 

unique_ptr<IMAWB>FCmpExecute::Execute(){
  /*�ǂ��炩�̃I�y�����h��nan�̏ꍇ���ʂ�1�ɂȂ�*/
  int result;
  IDecodeValue *dst = Operands[0];
  IDecodeValue *opr1 = Operands[1], *opr2 = Operands[2];
  int unordered = isnan(opr1->getDouble()) && isnan(opr2->getDouble());
  switch(_FCmpInst->getPredicate()){
  case CmpInst::FCMP_FALSE:
    {
      result = 0;
      break;
    }
  case CmpInst::FCMP_OEQ:
    {
      if(opr1->getDouble() == opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_OGT:
    {
      if(opr1->getDouble() < opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_OGE:
    {
      if(opr1->getDouble() <= opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_OLT:
    {
      if(opr1->getDouble() > opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_OLE:
    {
      if(opr1->getDouble() >= opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_ONE:
    {
      if(opr1->getDouble() != opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_ORD:
    {
      result = !unordered;
      break;
    }
  case CmpInst::FCMP_UNO:
    {
      result = unordered;
      break;
    }
  case CmpInst::FCMP_UEQ:
    {
      if(opr1->getDouble() == opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_UGT:
    {
      if(opr1->getDouble() < opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_UGE:
    {
      if(opr1->getDouble() <= opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_ULT:
    {
      if(opr1->getDouble() > opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_ULE:
    {
      if(opr1->getDouble() >= opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_UNE:
    {
      if(opr1->getDouble() != opr2->getDouble())
	result = !unordered;
      else
	result = 0;
      break;
    }
  case CmpInst::FCMP_TRUE:
    {
      result = 1;
      break;
    }
  }
  unique_ptr<IMAWB> rtn( new CmpMAWB(result,dst->getName()));
  return rtn;
}
