#ifndef CMPINST_H
#define CMPINST_H

#include"IRSimExe.hpp"
#include"IRSimMems.hpp"
#include"IRSimRegs.hpp"

namespace IRSIM{

  class ICmpExecute:public Execution{
  private:
    ICmpInst *_ICmpInst;
    ICmpExecute(const ICmpExecute &obj);
    operator=(const ICmpExecute &obj);
  public:
    ICmpExecute(ICmpInst *Inst):_ICmpInst(Inst){};
    ~ICmpExecute(){};
    unique_ptr<IMAWB>Execute();
  };

  class FCmpExecute:public Execution{
  private:
    FCmpInst *_FCmpInst;
    FCmpExecute(const FCmpExecute &obj);
    operator=(const FCmpExecute &obj);
  public:
    FCmpExecute(FCmpInst *Inst):_FCmpInst(Inst){};
    ~FCmpExecute(){};
    unique_ptr<IMAWB>Execute();
  };
  
  class CmpMAWB:public IMAWB{
  private:
    string WBRegisterName;
    int CmpResult;
    CmpMAWB(const CmpMAWB &obj);
    operator=(const CmpMAWB &obj);
  public:
    CmpMAWB(int resultcode, string RegisterName):CmpResult(resultcode),WBRegisterName(RegisterName){};
    ~CmpMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem)
    {
      RegT->setRegInt(CmpResult,WBRegisterName);
      RunInstResult MAWBRtn;
      return MAWBRtn;
    };
  };
  
}

#endif
