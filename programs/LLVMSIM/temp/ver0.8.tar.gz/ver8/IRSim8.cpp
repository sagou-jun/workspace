#include"IRSim8.hpp"
using namespace IRSIM;

IRSim::IRSim(){
  PC = 0;
  option = 's';
}

void IRSim::setIRFileName(string &FileName){
  LLVMContext &Context = getGlobalContext();
  SMDiagnostic Err;
  Owner = parseIRFile(FileName.c_str(),Err,Context);
  if(!Owner){
    Err.print(FileName.c_str(),errs());
    return ;
  }
  cerr<<"Print File Name = "<<FileName.substr(FileName.rfind("/")+1,FileName.rfind(".")-FileName.rfind("/"))+"profile"<<endl;
  //Performance.out.open(FileName.substr(FileName.rfind("/")+1,FileName.rfind(".")-FileName.rfind("/"))+"profile",ios::out); 
}

void AllocateGlobalValuesSwitch(Constant *Initializer,SIMMem *Mem,unsigned *AllocatedAddress){
  MemELE *GlobalValueMem;
  Type *InitializerType = Initializer->getType();
  switch(InitializerType->getTypeID()){
  case Type::IntegerTyID:
    {
      GlobalValueMem = Mem->getPtr(*AllocatedAddress);
      ConstantInt *IntValue = dyn_cast<ConstantInt>(Initializer);
      if(Initializer->getType()->getIntegerBitWidth() == 8)
	GlobalValueMem->setData(static_cast<char>(IntValue->getSExtValue()));
      else
	GlobalValueMem->setData(static_cast<int>(IntValue->getSExtValue()));
      *AllocatedAddress += 1;
      cerr<<*AllocatedAddress<<":"<<IntValue->getSExtValue()<<endl;
      break;
    }
  case Type::FloatTyID:
  case Type::DoubleTyID:
    {
      GlobalValueMem = Mem->getPtr(*AllocatedAddress);
      ConstantFP *DoubleValue = dyn_cast<ConstantFP>(Initializer);
      GlobalValueMem->setData(DoubleValue->getValueAPF().convertToDouble());
      *AllocatedAddress += 1;
      break;
    }
  case Type::PointerTyID:
    {
      GlobalValueMem = Mem->getPtr(*AllocatedAddress);
      ConstantInt *UnsignedValue = dyn_cast<ConstantInt>(Initializer);
      GlobalValueMem->setAdd(UnsignedValue->getZExtValue());
      *AllocatedAddress += 1;
      break;
    }
  case Type::ArrayTyID:
  case Type::StructTyID:
    {
      unsigned NumElements;
      if(InitializerType->getTypeID() == Type::ArrayTyID)
	NumElements = dyn_cast<ArrayType>(InitializerType)->getNumElements();
      else
	NumElements = dyn_cast<StructType>(InitializerType)->getNumElements();
      for(unsigned i = 0;i < NumElements;++i)
	{
	  Constant *InitializerConstantValue = Initializer->getAggregateElement(i);
	  AllocateGlobalValuesSwitch(InitializerConstantValue,Mem,AllocatedAddress);	  
	}
      break;
    }
  }
}

void IRSim::AllocateGlobalVariables(){
  Module *Mod = Owner.get();
  Module::GlobalListType &ListOfGlobal = Mod->getGlobalList();
  cerr<<"GlobalList size ="<<ListOfGlobal.size()<<endl;
  int count = 0;
  Decode decode(&RegT,&Mem,&FunctionStack);
  MAWB Mawb(&RegT,&Mem);
  for(Module::global_iterator GI = Mod->global_begin(),GIEnd = Mod->global_end();
      GI != GIEnd;
      GI++)
    {
      Execution *ex = decode.CreateGlobalVariableAllocaExecution(GI);
      Mawb.setInstance(ex->Execute());
      Mawb.Execute();
      Finalize(ex,&Mawb);
      Constant *Initializer = GI->getInitializer();
      unsigned AllocatedAddress = Mem.getLatestAllocatedAddress();
      if(Initializer != NULL){
	if(!Initializer->isZeroValue())
	  AllocateGlobalValuesSwitch(Initializer,&Mem,&AllocatedAddress);
      }
    }
  return ;
}

IRSim::~IRSim(){
}

void IRSim::dump(){
  if(FunctionStack.size() > 1)
    FunctionStack.dump();
  RegT.dump();
  cerr<<endl;
  Mem.dump();
  //Performance.dump();
  //cerr<<"IRSim::dump() print"<<endl;
  Performance.print();
  //cerr<<"IRSIm::dump()  calling PerformanceEstimation::Total()"<<endl;
  cerr<<"TotalBest="<<Performance.TotalBest()<<", TotalWorst="<<Performance.TotalWorst()<<endl;
}

bool IRSim::MemDataInport(string &RegName,double Data,unsigned offset)
{
  cerr<<"IRSim::MemDataInport "<<RegName<<" "<<offset<<" "<<Data<<endl;
  RegTableELE *reg = RegT.RegLookUp(RegName);
  if(reg != NULL&&Mem.getPtr(reg->getAdd()) != NULL)
    {
      Mem.getPtr(reg->getAdd()+offset)->setData(Data);
      return true;
    }
  cerr<<"IRSim::MemDataInport Error"<<endl;
  return false;
}

bool IRSim::MemDataExport(string &RegName,double &Data,unsigned offset)
{
  cerr<<"IRSim::MemDataExport "<<RegName<<" "<<offset<<" ";
  RegTableELE *reg = RegT.RegLookUp(RegName);
  if(reg != NULL&&Mem.getPtr(reg->getAdd()) != NULL)
    {
      Data = Mem.getPtr(reg->getAdd()+offset)->getDouble();
      cerr<<"Data="<<Data<<endl;
      return true;
    }
  cerr<<"IRSim::MemDataExport Error"<<endl;
  return false;
}
