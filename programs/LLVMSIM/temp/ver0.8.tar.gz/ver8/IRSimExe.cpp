#include"IRSimExe.hpp"
#include"MemoryOp.hpp"
#include"BinaryOp.hpp"
#include"CmpInst.hpp"
#include"CastInst.hpp"
#include"TerminateInst.hpp"

using namespace IRSIM;

//LLVM�o�[�W�����ˑ�
//LLVM���C�u�����ɊY������֐����Ȃ��������ߍ쐬
//Alloca,Load,Store,GetElementPtr,Fence,AtomicCmpXchg,AtomicRMW���Y��
inline bool isMemoryOp(unsigned x){
  return x >= Instruction::Alloca && Instruction::AtomicRMW >= x;
}

template<>
int DecodeValue<int>::getInt(){return _Value;};
template<>
char DecodeValue<char>::getChar(){return _Value;};
template<>
double DecodeValue<double>::getDouble(){return _Value;};
template<>
unsigned DecodeValue<unsigned>::getUnsigned(){return _Value;};
template<>
int DecodeValue<unsigned>::getInt(){return _Value;};

template<>
bool DecodeValue<int>::isInteger(){return true;};
template<>
bool DecodeValue<char>::isChar(){return true;};
template<>
bool DecodeValue<double>::isDouble(){return true;};
template<>
bool DecodeValue<unsigned>::isUnsigned(){return true;};

template<typename t>
void DecodeValue<t>::dump(){cerr<<ValueName<<":"<<Type<<":"<<_Value<<endl;};


void setAllocatorSwitch(SIMMemAllocator *MemAllocator,Type *AllocatedType);

IRSimTypes::TypeID TypeConvert(Type *IRType){
  switch(IRType->getTypeID()){
  case Type::IntegerTyID:
    {
      unsigned bitwidth = IRType->getIntegerBitWidth();
      if(bitwidth == 8)
	return IRSimTypes::CHAR;
      else
	return IRSimTypes::INTEGER;
    }
  case Type::FloatTyID:
  case Type::DoubleTyID:
    {
      return IRSimTypes::DOUBLE;
    }
  case Type::ArrayTyID:
    {
      return IRSimTypes::ARRAY;
    }
  case Type::StructTyID:
    {
      return IRSimTypes::STRUCT;
    }
  case Type::PointerTyID:
    {
      return IRSimTypes::POINTER;
    }
  default:
    {
      cerr<<"IRSimExe.cpp TypeConvert"<<endl;
      return IRSimTypes::Other;
    }
  }
}

template<>
void PtrVec<IDecodeValue>::dump(){
  cerr<<"ValueName:Type:_Value"<<endl;
  for(PtrVec<IDecodeValue>::const_iterator I = this->const_begin(), End = this->const_end();
      I != End;I++)
    (*I)->dump();
}

IDecodeValue *Decode::apply(Value *OperandValue){
  IDecodeValue *NewDecodeValue;
  RegTableELE *reg;
  string RegisterName;
  switch(OperandValue->getType()->getTypeID()){
  case Type::IntegerTyID:
    {
      unsigned bitwidth = OperandValue->getType()->getIntegerBitWidth();
      ConstantInt *imm = dyn_cast<ConstantInt>(OperandValue);
      if(imm != NULL)
	{
	  RegisterName = "Immediate";
	  if(bitwidth == 8)
	    NewDecodeValue = new DecodeValue<char>(static_cast<char>(imm->getSExtValue()),RegisterName,IRSimTypes::CHAR,true);
	  else
	    NewDecodeValue = new DecodeValue<int>(imm->getSExtValue(),RegisterName,IRSimTypes::INTEGER,true);
	}
      else
	{
	  RegisterName = (OperandValue->hasName())? OperandValue->getName().str(): ValueNaming(OperandValue);
	  reg = RegT->setRegInt(0,RegisterName,false);
	  if(bitwidth == 8)
	    NewDecodeValue = new DecodeValue<char>(static_cast<char>(reg->getInt()),RegisterName,IRSimTypes::CHAR);
	  else
	    NewDecodeValue = new DecodeValue<int>(reg->getInt(),RegisterName,IRSimTypes::INTEGER);
	}
      break;
    }
  case Type::FloatTyID:
  case Type::DoubleTyID:
    {
      ConstantFP *imm = dyn_cast<ConstantFP>(OperandValue);
      if(imm != NULL)
	{
	  RegisterName = "Immediate";
	  NewDecodeValue = new DecodeValue<double>(imm->getValueAPF().convertToDouble(),RegisterName,IRSimTypes::DOUBLE,true);
	}
      else
	{
	  RegisterName = (OperandValue->hasName())? OperandValue->getName().str(): ValueNaming(OperandValue);
	  reg = RegT->setRegDouble(0,RegisterName,false);
	  NewDecodeValue = new DecodeValue<double>(reg->getDouble(),RegisterName,IRSimTypes::DOUBLE);
	}
      break;
    }
  case Type::ArrayTyID:
    {
      RegisterName = (OperandValue->hasName())? OperandValue->getName().str(): ValueNaming(OperandValue);
      reg = RegT->setRegAdd(0,RegisterName,false);
      reg->setType(IRSimTypes::ARRAY);
      NewDecodeValue = new DecodeValue<unsigned>(reg->getAdd(),RegisterName,IRSimTypes::ARRAY);
      break;
    }
  case Type::StructTyID:
    {
      RegisterName = (OperandValue->hasName())? OperandValue->getName().str(): ValueNaming(OperandValue);
      reg = RegT->setRegAdd(0,RegisterName,false);
      reg->setType(IRSimTypes::STRUCT);
      NewDecodeValue = new DecodeValue<unsigned>(reg->getAdd(),RegisterName,IRSimTypes::STRUCT);
      break;
    }
  case Type::PointerTyID:
    {
      RegisterName = (OperandValue->hasName())? OperandValue->getName().str(): ValueNaming(OperandValue); 
      PointerType *PtrType = dyn_cast<PointerType>(OperandValue->getType());
      if(PtrType == NULL)
	{
	  cerr<<"Decode::apply dyn_cast error"<<endl;
	  exit(1);
	}
      IRSimTypes PointedType = TypeConvert(PtrType->getElementType());
      IRSimTypes NewType(IRSimTypes::POINTER,PointedType.getTypeID());
      RegTableELE *reg = RegT->setRegAdd(0,RegisterName,false);
      if(PointedType == IRSimTypes::ARRAY || PointedType == IRSimTypes::STRUCT)
	reg->setType(PointedType);
      NewDecodeValue = new DecodeValue<unsigned>(reg->getAdd(),RegisterName,NewType);
      break;
    }
  default:
    {
      cerr<<"Decode::apply TypeCheckError"<<endl;
      exit(1);
    }
  }
  return NewDecodeValue;
}

Execution *Decode::CreateExecution(Instruction *Inst){
  unsigned opcode = Inst->getOpcode();
  unsigned NumOperands = Inst->getNumOperands();
  Execution *NewExecution;
  
  if(Inst->isBinaryOp())
    {
      BinaryOperator *BinaryOp = dyn_cast<BinaryOperator>(Inst);
      NewExecution = new BinaryOpExecute(BinaryOp);
      NewExecution->setOperand(this->apply(Inst));
      for(int i = 0;i < NumOperands;++i)
	NewExecution->setOperand(this->apply(Inst->getOperand(i)));
    }
  else if(Inst->isTerminator())
    {
    }
  else if(Inst->isShift())
    {
    }
  else if(Inst->isCast())
    {
      CastInst *castInst = dyn_cast<CastInst>(Inst);
      NewExecution = new CastInstExecute(castInst);
      NewExecution->setOperand(this->apply(castInst));
      for(int i = 0;i < NumOperands;++i)
	NewExecution->setOperand(this->apply(Inst->getOperand(i)));
    }
  else if(isMemoryOp(opcode))
    {
      switch(opcode){
      case Instruction::Alloca:
	{
	  SIMMemAllocator MemAllocator(Mem);
	  AllocaInst *allocainst = dyn_cast<AllocaInst>(Inst);
	  Type *allocatedType = allocainst->getType();
	  if(allocainst->isArrayAllocation())
	    {
	      //�����炭�o�O��
	      MemAllocator.setAllocator(new AllocatorArray(dyn_cast<ArrayType>(allocainst->getAllocatedType())));
	    }
	  else	
	    setAllocatorSwitch(&MemAllocator,allocatedType);
	  NewExecution = new AllocaExecute(&MemAllocator);
	  NewExecution->setOperand(this->apply(Inst));
	  for(int i = 0;i < NumOperands;++i)
	    {
	      NewExecution->setOperand(this->apply(allocainst->getOperand(i)));
	    }
	  break;
	}
      case Instruction::Store:
	{
	  GEPOperator *gepOp = dyn_cast<GEPOperator>(Inst->getOperand(0));
	  if(gepOp == NULL)
	    {
	      NewExecution = new StoreExecute();
	      for(int i = 0;i < NumOperands;++i)
		NewExecution->setOperand(this->apply(Inst->getOperand(i)));
	    }
	  break;
	}
      case Instruction::Load:	
	{
	  NewExecution = new LoadExecute();
	  NewExecution->setOperand(this->apply(Inst));
	  for(int i = 0;i < NumOperands;++i)
	    NewExecution->setOperand(this->apply(Inst->getOperand(i)));
	  break;
	}
      case Instruction::GetElementPtr:
	{
	  GetElementPtrInst *GEPInst = dyn_cast<GetElementPtrInst>(Inst);
	  NewExecution = new GEPExecute(GEPInst);
	  NewExecution->setOperand(this->apply(Inst));
	  GEPOperator *gepOp = dyn_cast<GEPOperator>(Inst->getOperand(0));
	  if(gepOp != NULL)
	    {
	      cerr<<"Decode::CreateExecution GetElementPtrInst GEPOperator"<<endl;
	      exit(1);
	    }
	  for(int i = 0;i < NumOperands;++i)
	    {
	      NewExecution->setOperand(this->apply(Inst->getOperand(i)));
	    }
	  break;
	}
      }
    }
  else
    switch(opcode){
    case Instruction::ICmp:
      {
	ICmpInst *_ICmpInst = dyn_cast<ICmpInst>(Inst);
	NewExecution = new ICmpExecute(_ICmpInst);
	NewExecution->setOperand(this->apply(Inst));
	for(int i = 0;i < NumOperands;++i)
	  NewExecution->setOperand(this->apply(Inst->getOperand(i)));
	break;
      }
    case Instruction::FCmp:
      {
	FCmpInst *_FCmpInst = dyn_cast<FCmpInst>(Inst);
	NewExecution = new FCmpExecute(_FCmpInst);
	NewExecution->setOperand(this->apply(Inst));
	for(int i = 0;i < NumOperands;++i)
	  NewExecution->setOperand(this->apply(Inst->getOperand(i)));
	break;
      }
    default:
      {
	Inst->dump();
	cerr<<"have not implemented"<<endl;
	break;
      }
    }
  return NewExecution;
}

Execution *Decode::CreateGlobalVariableAllocaExecution(GlobalVariable *GV){
  SIMMemAllocator MemAllocator(Mem);
  cerr<<"Decode::CreateGlobalVariableAllocaExecution"<<endl;//���̈�s�������ƂȂ����o�O����������
  setAllocatorSwitch(&MemAllocator,GV->getType());
  Execution *NewExecution = new AllocaExecute(&MemAllocator);
  NewExecution->setOperand(this->apply(GV));
  return NewExecution;
}

void setAllocatorSwitch(SIMMemAllocator *MemAllocator,Type *AllocatedType){
  IAllocator *NewAllocator;
  switch(AllocatedType->getTypeID()){
  case Type::IntegerTyID:
    {
      unsigned bitwidth = AllocatedType->getIntegerBitWidth();
      if(bitwidth == 8)
	MemAllocator->setAllocator(new AllocatorImpl<char>());
      else
	MemAllocator->setAllocator(new AllocatorImpl<int>());
      break;
    }
  case Type::FloatTyID:
  case Type::DoubleTyID:
    {
      MemAllocator->setAllocator(new AllocatorImpl<double>());
      break;
    }
  case Type::ArrayTyID:
    {
      MemAllocator->setAllocator(new AllocatorArray(dyn_cast<ArrayType>(AllocatedType)));
      break;
    }
  case Type::StructTyID:
    {
      MemAllocator->setAllocator(new AllocatorStruct(dyn_cast<StructType>(AllocatedType)));
      break;
    }
  case Type::PointerTyID:
    {
      Type *ElementType = dyn_cast<PointerType>(AllocatedType)->getElementType();
      switch(ElementType->getTypeID()){
      case Type::IntegerTyID:
	{
	  unsigned bitwidth = ElementType->getIntegerBitWidth();
	  if(bitwidth == 8)
	    MemAllocator->setAllocator(new AllocatorImpl<char>());
	  else
	    MemAllocator->setAllocator(new AllocatorImpl<int>());
	  break;
	}
      case Type::FloatTyID:
      case Type::DoubleTyID:
	{
	  MemAllocator->setAllocator(new AllocatorImpl<double>());
	  break;
	}
      case Type::ArrayTyID:
	{
	  MemAllocator->setAllocator(new AllocatorArray(dyn_cast<ArrayType>(ElementType)));
	  break;
	}
      case Type::StructTyID:
	{
	  MemAllocator->setAllocator(new AllocatorStruct(dyn_cast<StructType>(ElementType)));
	  break;
	}
      case Type::PointerTyID:
	{
	  MemAllocator->setAllocator(new AllocatorImpl<unsigned>());
	  break;
	}
      }
      break;
    }
  }
}

void IRSIM::Finalize(Execution *ex,MAWB *mawb){
  delete ex;
  mawb->Finalize();
};

RunInstResult ErrorExit::Execute(RegTable *RegT,SIMMem *Mem){
  RunInstResult rtn(RunInstResultCode::ERROR_RUNINST);
  cerr<<"==========ERROR Exit============"<<endl;
  RegT->dump();
  cerr<<endl;
  Mem->dump();
  exit(1);
  return rtn;
};
