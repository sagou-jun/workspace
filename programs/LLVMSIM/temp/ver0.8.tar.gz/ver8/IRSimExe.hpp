#ifndef IR_SIM_EXE_H
#define IR_SIM_EXE_H
#include"IRSimUtils.hpp"
#include"IRSimRegs.hpp"
#include"IRSimMems.hpp"
#include"IRSimMemAllocator.hpp"

namespace IRSIM{
  class Decode;		//�f�R�[�h �������⃌�W�X�^����l�̓ǂݏo�����܂�
  class Execution;	//���s MAWB�Ń������E���W�X�^�ɏ����o���l���v�Z����
  class MAWB;		//�������E���W�X�^��������
  class IMAWB;		// MAWB�����C���^�t�F�[�X
  
  class IDecodeValue{
  public:
    virtual ~IDecodeValue(){};
    virtual bool isInteger() = 0;
    virtual bool isDouble() = 0;
    virtual bool isUnsigned() = 0;
    virtual bool isChar() = 0;
    virtual int getInt() = 0;
    virtual char getChar() = 0;
    virtual double getDouble() = 0;
    virtual unsigned getUnsigned() = 0;
    virtual string getName() = 0;
    virtual IRSimTypes getType() = 0;
    virtual void dump() = 0;
    virtual bool isImmediate() = 0;
  };
  
  template<typename t>
  class DecodeValue:public IDecodeValue{
  private:
    string ValueName;
    IRSimTypes Type;
    const t _Value;
    bool Immediate;
  public:
    DecodeValue(t v, string Name,IRSimTypes type,bool immediate=false):_Value(v),ValueName(Name),Type(type),Immediate(immediate){};
    ~DecodeValue(){}
    const t get(){return _Value;};
    int getInt(){cerr<<"DecodeValue::getInt this object does not have Int Value"<<endl;return 0;};
    double getDouble(){cerr<<"DecodeValue::getDouble this object does not have Double Value"<<endl;return 0;};
    unsigned getUnsigned(){cerr<<"DecodeValue::getUnsigned this object does not have Unsigned Value"<<endl;return 0;};
    char getChar(){cerr<<"DecodeValue::getUnsigned this object does not have Char Value"<<endl;return 0;};
    bool isInteger(){return false;};
    bool isDouble(){return false;};
    bool isUnsigned(){return false;};
    bool isChar(){return false;};
    string getName(){return ValueName;};
    IRSimTypes getType(){return Type;};
    bool isImmediate(){return Immediate;};
    void dump();
  };

  template<>
  int DecodeValue<int>::getInt();
  template<>
  char DecodeValue<char>::getChar();
  template<>
  double DecodeValue<double>::getDouble();
  template<>
  unsigned DecodeValue<unsigned>::getUnsigned();
  template<>
  int DecodeValue<unsigned>::getInt();

  template<>
  bool DecodeValue<int>::isInteger();
  template<>
  bool DecodeValue<char>::isChar();
  template<>
  bool DecodeValue<double>::isDouble();
  template<>
  bool DecodeValue<unsigned>::isUnsigned();

  /*�t�@�N�g���p�^�[����DecodeValue�I�u�W�F�N�g��Execution�I�u�W�F�N�g�𐶐�����*/
  class Decode{
  private:
    RegTable *RegT;
    SIMMem *Mem;
    Stack<StackELE> *PtrFunctionStack;
  public:
    Decode(RegTable *PtrRegT,SIMMem *PtrMem,Stack<StackELE> *stack):RegT(PtrRegT),Mem(PtrMem),PtrFunctionStack(stack){};
    ~Decode(){RegT = NULL;Mem = NULL;};
    IDecodeValue *apply(Value *OperandValue);
    Execution *CreateExecution(Instruction *Inst);
    Execution *CreateGlobalVariableAllocaExecution(GlobalVariable *GV);
  };

  template<>
  void PtrVec<IDecodeValue>::dump();
  
  class Execution{
  public:
    using OperandsList = PtrVec<IDecodeValue>;
    using iterator = OperandsList::iterator;
  protected:
    OperandsList Operands;
    unsigned NumOperands;
  public:
    Execution():NumOperands(0){};
    virtual ~Execution(){};
    void setOperand(IDecodeValue *operand){Operands.push_back(operand);++NumOperands;};
    iterator begin(){return Operands.begin();};
    iterator end(){return Operands.end();};
    virtual unique_ptr<IMAWB>Execute(){};
    void dump(){cerr<<"Execution::dump NumOperands = "<<NumOperands<<" "<<endl;Operands.dump();};
  };
  
  class IMAWB{
  private:
  public:
    IMAWB(){};
    IMAWB(const IMAWB &obj){};
    operator=(const IMAWB &obj){};
    virtual ~IMAWB(){};
    virtual RunInstResult Execute(RegTable *RegT,SIMMem *Mem) = 0;
  };
  
  class MAWB{
  private:
    RegTable *RegT;
    SIMMem *Mem;
    unique_ptr<IMAWB> PtrIMAWB;
    MAWB(const MAWB &obj);
    operator=(const MAWB &obj);
  public:
    MAWB(RegTable *PtrRegT,SIMMem *PtrMem):RegT(PtrRegT),Mem(PtrMem){};
    ~MAWB(){RegT = NULL;Mem = NULL;};
    void setInstance(unique_ptr<IMAWB>pIMAWB){PtrIMAWB = move(pIMAWB);};
    RunInstResult Execute(){PtrIMAWB->Execute(RegT,Mem);};
    void Finalize(){PtrIMAWB.release();};
  };

  //�G���[�ɂ���ď������I��������ꍇ
  class ErrorExit:public IMAWB{
  private:
    ErrorExit(const ErrorExit &obj);
    operator=(const ErrorExit &obj);
  public:
    ErrorExit(){};
    ~ErrorExit(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };

  // �������Ȃ�
  class DoNothing:public IMAWB{
  private:
    DoNothing(const DoNothing &obj);
    operator=(const DoNothing &obj);
  public:
    DoNothing(){};
    ~DoNothing(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mme){RunInstResult rtn;return rtn;}
  };
  
  void Finalize(Execution *ex,MAWB *mawb);
  
}
#endif
