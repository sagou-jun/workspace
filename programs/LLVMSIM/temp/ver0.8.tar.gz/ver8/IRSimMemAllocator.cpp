#include"IRSimMemAllocator.hpp"

using namespace IRSIM;

template<>
unsigned AllocatorImpl<int>::Allocate(SIMMem *Mem){
  return Mem->myAllocInt();
};
template<>
unsigned AllocatorImpl<unsigned>::Allocate(SIMMem *Mem){
  return Mem->myAllocPtr();
};
template<>
unsigned AllocatorImpl<double>::Allocate(SIMMem *Mem){
  return Mem->myAllocDouble();
};
template<>
unsigned AllocatorImpl<char>::Allocate(SIMMem *Mem){
  return Mem->myAllocChar();
};

unsigned AllocatorArray::Allocate(SIMMem *Mem){
  return Mem->myAllocArray(_ArrayType);
};

unsigned AllocatorStruct::Allocate(SIMMem *Mem){
  return Mem->myAllocStruct(_StructType);
};

unsigned SIMMemAllocator::Allocate(){
  unsigned addr = _IAllocator->Allocate(Mem);
  delete _IAllocator;
  _IAllocator = NULL;
  return addr;
};
