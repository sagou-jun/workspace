#ifndef IR_SIM_MEMALLOCATOR_H
#define IR_SIM_MEMALLOCATOR_H

#include"IRSimMems.hpp"
namespace IRSIM{
  
  class IAllocator{
  public:
    IAllocator(){};
    virtual ~IAllocator(){};
    virtual unsigned Allocate(SIMMem *Mem) = 0;
  };
  
  template<typename t>
  class AllocatorImpl:public IAllocator{
  public:
    AllocatorImpl(){};
    ~AllocatorImpl(){};
    unsigned Allocate(SIMMem *Mem);
  };

  template<>
  unsigned AllocatorImpl<int>::Allocate(SIMMem *Mem);
  template<>
  unsigned AllocatorImpl<unsigned>::Allocate(SIMMem *Mem);
  template<>
  unsigned AllocatorImpl<double>::Allocate(SIMMem *Mem);
  template<>
  unsigned AllocatorImpl<char>::Allocate(SIMMem *Mem);

  class AllocatorArray:public IAllocator{
  private:
    ArrayType *_ArrayType;
  public:
    AllocatorArray(ArrayType *arraytype):_ArrayType(arraytype){};
    ~AllocatorArray(){};
    unsigned Allocate(SIMMem *Mem);
  };

  class AllocatorStruct:public IAllocator{
  private:
    StructType *_StructType;
  public:
    AllocatorStruct(StructType *structtype):_StructType(structtype){};
    ~AllocatorStruct(){};
   unsigned Allocate(SIMMem *Mem);
  };
  
  class SIMMemAllocator{
  private:
    SIMMem *Mem;
    IAllocator* _IAllocator;
    SIMMemAllocator(const SIMMemAllocator &obj);
    operator=(const SIMMemAllocator &obj);
  public:
    SIMMemAllocator(SIMMem *mem):Mem(mem){};
    ~SIMMemAllocator(){};
    void setAllocator(IAllocator *PtrIAllocator){_IAllocator = PtrIAllocator;};
    unsigned Allocate();
  };

}
#endif
