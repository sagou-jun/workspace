#include"IRSimMems.hpp"
#include<cctype>

using namespace IRSIM;

MemELE::MemELE(){
}

inline char *CtrlToLiteral(char c){
  switch(c){
  case '\0':
    return "\\0";
  case '\a':
    return "\\a";
  case '\b':
    return "\\b";
  case '\t':
    return "\\t";
  case '\n':
    return "\\n";
  case '\v':
    return "\\v";
  case '\f':
    return "\\f";
  case '\r':
    return "\\r";
  default:
    return "Not Literal Ctrl Charactor";
  }
}

template<typename t>
void MemData<t>::dump(){
  cerr<<setw(Data_width)<<fixed<<Data<<":"<<_Type.str();
};

template<>
void MemData<char>::dump(){
  cerr<<setw(Data_width)<<fixed;
  if(iscntrl(Data))
    cerr<<CtrlToLiteral(Data);
  else
    cerr<<Data;
  cerr<<":"<<_Type.str();
}

template<>
MemData<char>::MemData(char data):Data(data){_Type = IRSimTypes::CHAR;};
template<>
MemData<int>::MemData(int data):Data(data){_Type = IRSimTypes::INTEGER;};
template<>
MemData<double>::MemData(double data):Data(data){_Type = IRSimTypes::DOUBLE;};
template<>
MemData<unsigned>::MemData(unsigned data):Data(data){_Type = IRSimTypes::POINTER;};

template<>
inline int MemData<int>::getInt(){return Data;}
template<>
inline double MemData<double>::getDouble(){return Data;}
template<>
inline unsigned MemData<unsigned>::getAdd(){return Data;}
template<>
inline char MemData<char>::getChar(){return Data;}

template<>
inline void MemData<char>::setData(char c){Data = c;}
template<>
inline void MemData<int>::setData(int i){Data = i;}
template<>
inline void MemData<double>::setData(double d){Data = d;}
template<>
inline void MemData<unsigned>::setAdd(unsigned u){Data = u;}

SIMMem::SIMMem(){
  NumOfData = 0;
  LatestAllocatedAddress = 0;

  //�Y������0�̃������͏�ɒl��0��NULL�|�C���^�Ɠ����l�Ɏg��
  Mems[0].check = true;
  Mems[0].region = false;
  Mems[0].mem = new MemData<int>(0);
  Mems[0].mem->setType(IRSimTypes::VOID);
}

SIMMem::~SIMMem(){
  for(unsigned i = 0;i < MemMax;i++)
    if(Mems[i].check)
      delete Mems[i].mem;
}

MemELE *SIMMem::getPtr(unsigned addr){
  if(addr == 0)
    {
      cerr<<"SIMMem::getPtr NULL Pointer Access"<<endl;
      return NULL;
    }
  if(!Mems[addr].check)
    cerr<<"Address="<<addr<<" is not Allocated"<<endl;
  return Mems[addr].mem;
}

unsigned SIMMem::myAllocImp(IRSimTypes t,int idata,double ddata,unsigned udata,unsigned Num){
  if((NumOfData+Num) > MemMax)
    {
      cerr<<"SIMMem::myAlloc Error(Insufficient Memory 1)"<<endl;
      return 0;
    }
  
  int count = 1;
  unsigned rtn = 1;/*�������̐擪�ɖ��g�p�̗̈悪�������ꍇ1���Ԃ�*/
  unsigned i = 1;//�A�h���X��0�̃������ɂ͊��蓖�ĂȂ�
  for(;i < MemMax;i++)
    {
      /*����Num�Ɠ������̘A���������g�p�̗̈��T��*/
      if(!Mems[i].check)
	{
	  if(count == Num)
	    break;
	  count++;
	}
      else
	{
	  count = 1;
	  rtn = i + 1;
	}
      if((i + Num - count) >= MemMax)
	{
	  cerr<<"SIMMem::myAlloc Error(Insufficient Memory 2)"<<endl;
	  return 0;
	}
    }
  /*switch���O���̕������s�������ǂ��Ȃ邩���m��Ȃ�*/
  switch(t){
  case IRSimTypes::CHAR:
    {
        for(i = rtn;count > 0;count--,++i)
	  {
	    Mems[i].mem = new MemData<char>(static_cast<char>(idata));
	    Mems[i].check = true;
	    Mems[i].region = (count == 1)?false:true;
	  }
	break;
    }
  case IRSimTypes::INTEGER:
    {
      for(i = rtn;count > 0;count--,++i)
	{
	  Mems[i].mem = new MemData<int>(idata);
	  Mems[i].check = true;
	  Mems[i].region = (count == 1)?false:true;
	}
      break;
    }
  case IRSimTypes::DOUBLE:
    {
      for(i = rtn;count > 0;count--,++i)
	{
	  Mems[i].mem = new MemData<double>(ddata);
	  Mems[i].check = true;
	  Mems[i].region = (count == 1)?false:true;
	}
      break;
    }
  case IRSimTypes::POINTER:
    {
      for(i = rtn;count > 0;count--,++i)
	{
	  Mems[i].mem = new MemData<unsigned>(udata);
	  Mems[i].check = true;
	  Mems[i].region = (count == 1)?false:true;
	}      
      break;
    }
  }

  NumOfData += Num;
  LatestAllocatedAddress = rtn;
  return rtn;
}

unsigned SIMMem::myAllocArray(ArrayType *NewArray){
  unsigned Num = CalcAggregateTypeSize(NewArray);
  if(NumOfData+Num >= MemMax)
    {
      cerr<<"SIMMem::myAlloc Error(Insufficient Memory 1)"<<endl;
      exit(1);
    }
  int count = 1;
  unsigned rtn = 1;/*�������̐擪�ɖ��g�p�̗̈悪�������ꍇ1���Ԃ�*/
  unsigned i = 1;
  for(;i < MemMax;++i)
    {
      if(!Mems[i].check)
	{
	  if(count == Num)
	    break;
	  else
	    count++;
	}
      else
	{
	  count = 1;
	  rtn = i + 1;
	}
      if((i + Num - count) >= MemMax)
	{
	  cerr<<"SIMMem::myAlloc Error(Insufficient Memory 2)"<<endl;
	  exit(1);
	}
    }
  cerr<<"myAllocArray "<<CalcAggregateTypeSize(NewArray)<<", "<<rtn<<endl;
  AllocArrayProcess(rtn, NewArray);
  Mems[rtn+Num-1].region = false;
  NumOfData += Num;
  LatestAllocatedAddress = rtn;
  return rtn;
}

unsigned SIMMem::myAllocStruct(StructType *NewStruct){
  unsigned Num = CalcAggregateTypeSize(NewStruct);
  if(NumOfData+Num >= MemMax)
    {
      cerr<<"SIMMem::myAlloc Error(Insufficient Memory 1)"<<endl;
      return 0;
    }
  int count = 1;
  unsigned rtn = 1;/*�������̐擪�ɖ��g�p�̗̈悪�������ꍇ1���Ԃ�*/
  unsigned i = 1;
  for(;i < MemMax;++i)
    {
      if(!Mems[i].check)
	{
	  if(count == Num)
	    break;
	  else
	    count++;
	}
      else
	{
	  count = 1;
	  rtn = i + 1;
	}
      if((i + Num - count) >= MemMax)
	{
	  cerr<<"SIMMem::myAlloc Error(Insufficient Memory 2)"<<endl;
	  return 0;
	}
    }
  cerr<<"myAllocStruct "<< CalcAggregateTypeSize(NewStruct)<<", "<<rtn<<endl;
  AllocStructProcess(rtn, NewStruct);
  Mems[rtn+Num-1].region = false;
  NumOfData += Num;
  LatestAllocatedAddress = rtn;
  return rtn;
}

bool SIMMem::myFree(unsigned addr){
  /*addr���������͈̔͊O���邢�͂��̃A�h���X�̃����������g�p�̏ꍇ�G���[*/
  if((addr <= 0&&MemMax <= addr)||(!Mems[addr].check))
    {
      cerr<<"SIMMem::myFree Error(Invalid Address) "<<addr<<endl;
      return false;
    }
  int i;
  for(i = addr;Mems[i].check;++i)
    {
      /*�A�h���X������Ȕ͈͂ł��邱�Ƃ��m�F����*/
      if(i >= MemMax)
	{
	  cerr<<"SIMMem::myFree Error(Abnormaly Data)"<<endl;
	  return false;
	}
      /*�������̉��*/
      delete Mems[i].mem;
      Mems[i].check = false;
      /*��������̃f�[�^���̃`�F�b�N*/
      if(NumOfData == 0)
	cerr<<"SIMMem::myFree Error(Invalid Access)"<<endl;
      NumOfData--;
      /*�m�ۂ����̈�̖��[�ɓ��B�����ꍇ*/
      if(!Mems[i].region)
	{
	  cerr<<"SIMMem::myFree end="<<i<<endl;
	  break;
	}
    }
  cerr<<"SIMMem::myFree "<<addr<<" to "<<i<<endl;
  return true;
}

void SIMMem::dump(){
  cerr<<"RealAdd    :Address:Data:Kind:NumOfData="<<NumOfData<<endl;
  cerr<<setw(Address_width)<<Mems[0].mem;
  cerr<<":";
  cerr<<setw(Address_width)<<"0";
  cerr<<":           :";
  cerr<<setw(Data_width)<<fixed<<"0";
  cerr<<":VOID"<<endl;
  for(unsigned i = 1,count = 0;(count < NumOfData)&&(i < MemMax);++i)
    if(Mems[i].check)
      {
	cerr<<setw(Address_width)<<Mems[i].mem;
	cerr<<":";
	cerr<<setw(Address_width)<<i<<":";
	if(Mems[i].check&&(!Mems[i].region))
	  cerr<<"(BlockEnd) ";
	else
	  cerr<<"           ";
	cerr<<":";
	Mems[i].mem->dump();
	if(Mems[i].SubType == IRSimTypes::ARRAY)
	  cerr<<":"<<"ARRAY";
	else if(Mems[i].SubType == IRSimTypes::STRUCT)
	  cerr<<":"<<"STRUCT";
	cerr<<endl;
	count++;
      }
}

void SIMMem::dump(unsigned i){
  if(Mems[i].check)
    {
      cerr<<setw(Address_width)<<Mems[i].mem;
      cerr<<":";
      cerr<<setw(Address_width)<<i<<":";
      if(Mems[i].check&&(!Mems[i].region))
	cerr<<"(BlockEnd) ";
      else
	cerr<<"           ";
      cerr<<":";
      Mems[i].mem->dump();
      if(Mems[i].SubType == IRSimTypes::ARRAY)
	cerr<<":"<<"ARRAY";
      else if(Mems[i].SubType == IRSimTypes::STRUCT)
	cerr<<":"<<"STRUCT";
      cerr<<endl;
    }
}

void SIMMem::AllocArrayProcess(unsigned addr,ArrayType *NewArray){
  unsigned Num = NewArray->getArrayNumElements();
  unsigned i = addr;
  while(1)
    {
      if(!Mems[i].check)
	break;
      ++i;
    }

  switch(NewArray->getElementType()->getTypeID()){
  case Type::IntegerTyID:
    {
      switch(NewArray->getElementType()->getIntegerBitWidth()){
      case 8:
	{
	  for(unsigned count = 0;count < Num;++i,++count)
	    {
	      Mems[i].mem = new MemData<char>(0);
	      Mems[i].check = true;
	      Mems[i].SubType = IRSimTypes::ARRAY;
	    }
	  break;
	}
      default:
	{
	  for(unsigned count = 0;count < Num;++i,++count)
	    {
	      Mems[i].mem = new MemData<int>(0);
	      Mems[i].check = true;
	      Mems[i].SubType = IRSimTypes::ARRAY;
	    }
	  break;
	}
      }
      break;
    }
  case Type::FloatTyID:
  case Type::DoubleTyID:
    {
      for(unsigned count = 0;count < Num;++i,++count)
	{
	  Mems[i].mem = new MemData<double>(0);
	  Mems[i].check = true;
	  Mems[i].SubType = IRSimTypes::ARRAY;
	}
      break;
    }
  case Type::StructTyID:
    {
      for(unsigned count = 0;count < Num;++count)
	AllocStructProcess(i,dyn_cast<StructType>(NewArray->getElementType()));
      break;
    }
  case Type::ArrayTyID:
    {
      for(unsigned count = 0;count < Num;++count)
	AllocArrayProcess(i,dyn_cast<ArrayType>(NewArray->getElementType()));
      break;
    }
  case Type::PointerTyID:
    {
      for(unsigned count = 0;count < Num;++i,++count)
	{
	  Mems[i].mem = new MemData<unsigned>(0);
	  Mems[i].check = true;
	  Mems[i].SubType = IRSimTypes::ARRAY;
	}
      break;
    }
  default:
    {
      cerr<<"SIMMem::myAllocaStruct This element Typ is unimmplementede"<<endl;
      break;
    }
  }
  return ;
}

void SIMMem::AllocStructProcess(unsigned addr,StructType *NewStruct){
  unsigned Num = NewStruct->getStructNumElements();
  int count = 1;
  unsigned rtn = 1;/*�������̐擪�ɖ��g�p�̗̈悪�������ꍇ1���Ԃ�*/
  unsigned i = 1;//�A�h���X��0�̃������ɂ͊��蓖�ĂȂ�
  for(;i < MemMax;++i)
    {
      if(!Mems[i].check)
	{
	  if(count == Num)
	    break;
	  else
	    count++;
	}
      else
	{
	  count = 1;
	  rtn = i + 1;
	}
      if((i + Num - count) >= MemMax)
	{
	  cerr<<"SIMMem::myAlloc Error(Insufficient Memory 2)"<<endl;
	  return ;
	}
    }

  //count = Num//���̎��_�ł͊m����count=Num
  i = rtn;
  for(unsigned j = 0;0 < count;++j,++i,--count)
    {
      switch(NewStruct->getElementType(j)->getTypeID()){
      case Type::IntegerTyID:
	{
	  switch(NewStruct->getElementType(j)->getIntegerBitWidth()){
	  case 8:
	    {
	      Mems[i].mem = new MemData<char>(0);
	      break;
	    }
	  default :
	    {
	      Mems[i].mem = new MemData<int>(0);
	      break;
	    }
	  }
	  break;
	}
      case Type::FloatTyID:
      case Type::DoubleTyID:
	{
	  Mems[i].mem = new MemData<double>(0);
	  break;
	}
      case Type::StructTyID:
	{
	  AllocStructProcess(addr,dyn_cast<StructType>(NewStruct->getElementType(j)));
	  break;
	}
      case Type::ArrayTyID:
	{
	  AllocArrayProcess(addr,dyn_cast<ArrayType>(NewStruct->getElementType(j)));
	  break;
	}
      case Type::PointerTyID:
	{
	  /*���W�X�^�e�[�u�����Ȃ���΃|�C���^�̏��������o���Ȃ�*/
	  Mems[i].mem = new MemData<unsigned>(0);
	  break;
	}
      default:
	{
	  cerr<<"SIMMem::myAllocaStruct This element Typ is unimmplementede"<<endl;
	  break;
	}
      }
      Mems[i].check = true;
      Mems[i].SubType = IRSimTypes::STRUCT;
    }
  return ;
}
