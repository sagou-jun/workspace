#ifndef IR_SIM_MEMS_H
#define IR_SIM_MEMS_H
#include<cstdio>
#include<iostream>
#include<iomanip>
#include"IRSimUtils.hpp"

namespace IRSIM{
#define Address_width 4
#define Data_width 5
  
  // ���ۃN���X
  class MemELE{
  protected:
    IRSimTypes _Type;
    MemELE();
  public:
    virtual ~MemELE(){};
    IRSimTypes getType(){return _Type;};
    void setType(IRSimTypes type){_Type = type;};
    /*�T�u�N���X�p�C���^�[�t�F�[�X*/
    virtual char getChar() = 0;
    virtual int getInt() = 0;
    virtual double getDouble() = 0;
    virtual unsigned getAdd() = 0;
    virtual void setData(char s) = 0;
    virtual void setData(int i) = 0;
    virtual void setData(double d) = 0;
    virtual void setAdd(unsigned u) = 0;
    virtual void dump() = 0;
  };
  
  template<typename t>
  class MemData:public MemELE{
  private:
    t Data;
  public:
    MemData(){};
    MemData(t data){};
    ~MemData(){};
    /*���ꉻ�ɂ���Ď�������*/
    virtual char getChar()		{cerr<<"MemData::getChar This Object doesnot have Char Value"<<endl;};
    virtual int getInt()		{cerr<<"MemData::getInt    This Object doesnot have Int Value"<<endl;return 0;};
    virtual double getDouble()		{cerr<<"MemData::getDouble This Object doesnot have Double Value"<<endl;return 0;};
    virtual unsigned getAdd()		{cerr<<"MemData::getAdd    This Object doesnot have Unsigned Value"<<endl;dump();return 0;};
    virtual void setData(char s)	{cerr<<"MemData::setData This Object doesnot have Char Value"<<endl;};
    virtual void setData(int i)		{cerr<<"MemData::setData This Object doesnot have Int Value"<<endl;};
    virtual void setData(double d)	{cerr<<"MemData::setData This Object doesnot have Double Value"<<endl;};
    virtual void setAdd(unsigned u)	{cerr<<"MemData::setData This Object doesnot have Unsigned Value"<<endl;dump();}
    void dump();
  };

  template<>
  void MemData<char>::dump();
  
  template<>
  MemData<char>::MemData(char data);
  template<>
  MemData<int>::MemData(int data);
  template<>
  MemData<double>::MemData(double data);
  template<>
  MemData<unsigned>::MemData(unsigned data);
  template<>  
  char MemData<char>::getChar();
  template<>
  int MemData<int>::getInt();
  template<>
  double MemData<double>::getDouble();
  template<>
  unsigned MemData<unsigned>::getAdd();
  template<>
  void MemData<char>::setData(char c);
  template<>
  void MemData<int>::setData(int i);
  template<>
  void MemData<double>::setData(double d);
  template<>
  void MemData<unsigned>::setAdd(unsigned u);

  /*�������A�h���X�̏��*/
#define MemMax	       2000
  
  struct Memory {
  public:
    MemELE *mem;
    bool check;			// true:�g�p�� false:���g�p
    bool region;		// check == true�̂Ƃ� true:���蓖�Ă��̈�̈ꕔ false:���蓖�Ă��̈�̖��[
				// check == false�̂Ƃ��@����`
    IRSimTypes::TypeID SubType;	// Array or Struct TypeId
    Memory():mem(NULL),check(false),region(true),SubType(IRSimTypes::VOID){};
    ~Memory(){};
  };
  
  class SIMMem{
  private:
    unsigned NumOfData;	// �g�p���̃f�[�^�̐�
    Memory Mems[MemMax];// ���̔z��̓Y�������A�h���X�Ƃ��A�A�h���X���O�̃������͎g�p���Ȃ�
    unsigned LatestAllocatedAddress;
    unsigned myAllocImp(IRSimTypes t,int idata,double ddata,unsigned udata,unsigned Num = 1);
    void AllocArrayProcess(unsigned addr,ArrayType *NewArray);
    void AllocStructProcess(unsigned addr,StructType *NewStruct);
  public:
    SIMMem();
    ~SIMMem();
    MemELE *getPtr(unsigned addr);
    unsigned getLatestAllocatedAddress(){return LatestAllocatedAddress;};
    unsigned myAllocInt(int data=0,unsigned Num=1){return myAllocImp(IRSimTypes::INTEGER,data,0,0,Num);};
    unsigned myAllocChar(int data=0,unsigned Num=1){return myAllocImp(IRSimTypes::CHAR,data,0,0,Num);};
    unsigned myAllocDouble(double data=0,unsigned Num=1){return myAllocImp(IRSimTypes::DOUBLE,0,data,0,Num);};
    unsigned myAllocPtr(unsigned data=0,unsigned Num=1){return myAllocImp(IRSimTypes::POINTER,0,0,data,Num);};
    unsigned myAllocStruct(StructType *NewStruct);
    unsigned myAllocArray(ArrayType *NewArray);
    unsigned getNumOfData(){return NumOfData;};
    bool myFree(unsigned addr);
    void dump();
    void dump(unsigned i);
  };
}
#endif
