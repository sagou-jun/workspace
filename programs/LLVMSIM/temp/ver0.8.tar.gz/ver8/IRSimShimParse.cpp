#include"IRSim8.hpp"
#include"shim_parse_2.hxx"

using namespace IRSIM;
/*���̃v���O�����ƃR���p�C���I�v�V�������قȂ邽�߁C���̃t�@�C���ȊO��shim_parse_2.hxx���C���N���[�h���������Ȃ�*/

static SHIM_PARSE::shim_parse *SHIM_PARSE_OBJ = NULL;

void IRSim::Init_SHIM_PARSER(string ShimXmlFileName){
  static SHIM_PARSE::shim_parse shim(ShimXmlFileName);
  SHIM_PARSE_OBJ = &shim;
}

bool IRSim::GetBestLatency(BasicBlock *BB){
  if(SHIM_PARSE_OBJ == NULL)
    {
      return false;
    }
  double BasicBlockBest = 0;
  for(BasicBlock::iterator InstI = BB->begin(),InstI_End = BB->end();
      InstI != InstI_End;
      InstI++)
    {
      BasicBlockBest += SHIM_PARSE_OBJ->get_latency(InstI->getOpcodeName(),BEST,"\0");
    }
  Performance.BestLatency.setLatency(BB->getParent()->getName().str(),BB->getName().str(),BasicBlockBest);
  return true;
}

bool IRSim::GetWorstLatency(BasicBlock *BB){
  if(SHIM_PARSE_OBJ == NULL)
    {
      return false;
    }
  double BasicBlockWorst = 0;
  for(BasicBlock::iterator InstI = BB->begin(),InstI_End = BB->end();
      InstI != InstI_End;
      InstI++)
    {
      BasicBlockWorst += SHIM_PARSE_OBJ->get_latency(InstI->getOpcodeName(),WORST,"\0");
    }
  Performance.WorstLatency.setLatency(BB->getParent()->getName().str(),BB->getName().str(),BasicBlockWorst);
  return true;
}
