#include"IRSim8.hpp"
#include<iostream>
#include<cstring>

using namespace IRSIM;

int main(int argc,char *argv[],const *envp){
  IRSim SIM;
  char recv[256];
  int Station;
  if(argc < 2)
    {
      cerr<<"no input file"<<std::endl;
      cerr<<"usage LLVMSim8.exe <IRFile> [<ShimXMLFile>]/[-{f|i|b|s}]"<<endl;
      exit(1);
    }
  else if(argc >= 3)
    {
      if(argv[2][0] != '-')
	SIM.Init_SHIM_PARSER(argv[2]);
      else
	SIM.Setoption(argv[2][1]);
    }
  string FileName(argv[1]);
  SIM.Run(FileName);
  return 0;
}
