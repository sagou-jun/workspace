#include"MemoryOp.hpp"

using namespace IRSIM;

unique_ptr<IMAWB>AllocaExecute::Execute(){
  unique_ptr<IMAWB> rtn(new AllocaMAWB(_MemAllocator->Allocate(),Operands[0]->getName()));
  return rtn;
};

unique_ptr<IMAWB>StoreExecute::Execute(){
  IMAWB *NewStoreMAWB;
  switch(Operands[1]->getType().getTypeID())
    {
    case IRSimTypes::INTEGER:
      NewStoreMAWB = new StoreMAWB<int>(Operands[1]->getUnsigned(),Operands[0]->getInt());
      break;
    case IRSimTypes::CHAR:
      NewStoreMAWB = new StoreMAWB<char>(Operands[1]->getUnsigned(),Operands[0]->getChar());
      break;      
    case IRSimTypes::DOUBLE:
      NewStoreMAWB = new StoreMAWB<double>(Operands[1]->getUnsigned(),Operands[0]->getDouble());
      break;
    case IRSimTypes::ARRAY:
    case IRSimTypes::STRUCT:
     	cerr<<"Error StoreExecute::Execute not Implemented"<<endl;
	exit(1);
    case IRSimTypes::POINTER:
      switch(Operands[1]->getType().getPointedType()->getTypeID())
	{
	case IRSimTypes::INTEGER:
	  NewStoreMAWB = new StoreMAWB<int>(Operands[1]->getUnsigned(),Operands[0]->getInt());
	  break;
	case IRSimTypes::CHAR:
	  cerr<<"Operands[1]->getUnsigned "<<Operands[1]->getUnsigned()<<endl;
	  NewStoreMAWB = new StoreMAWB<char>(Operands[1]->getUnsigned(),Operands[0]->getChar());
	  break;      
	case IRSimTypes::DOUBLE:
	  NewStoreMAWB = new StoreMAWB<double>(Operands[1]->getUnsigned(),Operands[0]->getDouble());
	  break;
	case IRSimTypes::ARRAY:
	case IRSimTypes::STRUCT:
	case IRSimTypes::POINTER:
	  NewStoreMAWB = new StoreMAWB<unsigned>(Operands[1]->getUnsigned(),Operands[0]->getUnsigned());
	  break;
	}
      break;
    }
  unique_ptr<IMAWB> rtn(NewStoreMAWB);
  return rtn;
}

template<>
RunInstResult StoreMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem){
  Mem->getPtr(Address)->setData(_Value);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult StoreMAWB<char>::Execute(RegTable *RegT,SIMMem *Mem){
  Mem->getPtr(Address)->setData(_Value);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}
    
template<>
RunInstResult StoreMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem){
  Mem->getPtr(Address)->setData(_Value);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult StoreMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem){
  Mem->getPtr(Address)->setAdd(_Value);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

unique_ptr<IMAWB>LoadExecute::Execute(){
  IMAWB *NewLoadMAWB;
  switch(Operands[1]->getType().getTypeID()){
  case IRSimTypes::INTEGER:
    NewLoadMAWB = new LoadMAWB<int>(Operands[0]->getName(),Operands[1]->getInt());
    break;
  case IRSimTypes::CHAR:
    NewLoadMAWB = new LoadMAWB<char>(Operands[0]->getName(),Operands[1]->getChar());
    break;
  case IRSimTypes::DOUBLE:
    NewLoadMAWB = new LoadMAWB<double>(Operands[0]->getName(),Operands[1]->getDouble());
    break;
  case IRSimTypes::ARRAY:
  case IRSimTypes::STRUCT:
    cerr<<"Error LoadExecute::Execute not Implemented"<<endl;
    exit(1);
  case IRSimTypes::POINTER:
    {
      switch(Operands[1]->getType().getPointedType()->getTypeID()){
      case IRSimTypes::INTEGER:
	NewLoadMAWB = new LoadMAWB<int>(Operands[0]->getName(),Operands[1]->getUnsigned());
	break;
      case IRSimTypes::CHAR:
	NewLoadMAWB = new LoadMAWB<char>(Operands[0]->getName(),Operands[1]->getChar());
	break;
      case IRSimTypes::DOUBLE:
	NewLoadMAWB = new LoadMAWB<double>(Operands[0]->getName(),Operands[1]->getUnsigned());
	break;
      case IRSimTypes::ARRAY:
      case IRSimTypes::STRUCT:
      case IRSimTypes::POINTER:
	NewLoadMAWB = new LoadMAWB<unsigned>(Operands[0]->getName(),Operands[1]->getUnsigned(),true);
	break;
      }
      break;
    }
  }

  unique_ptr<IMAWB> rtn(NewLoadMAWB);
  return rtn;
}

template<>
RunInstResult LoadMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem){
  if(Trace)
    RegT->setRegInt(Mem->getPtr(Address)->getInt(),RegisterName)->setTrace();
  else
    RegT->setRegInt(Mem->getPtr(Address)->getInt(),RegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult LoadMAWB<char>::Execute(RegTable *RegT,SIMMem *Mem){
  if(Trace)
    RegT->setRegInt(Mem->getPtr(Address)->getChar(),RegisterName)->setTrace();
  else
    RegT->setRegInt(Mem->getPtr(Address)->getChar(),RegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult LoadMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem){
  if(Trace)
    RegT->setRegDouble(Mem->getPtr(Address)->getDouble(),RegisterName)->setTrace();
  else
    RegT->setRegDouble(Mem->getPtr(Address)->getDouble(),RegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

template<>
RunInstResult LoadMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem){
  if(Trace)
    RegT->setRegAdd(Mem->getPtr(Address)->getAdd(),RegisterName)->setTrace();
  else
    RegT->setRegAdd(Mem->getPtr(Address)->getAdd(),RegisterName);
  RunInstResult MAWBRtn;
  return MAWBRtn;
}
  
void GEPExecute::CalcGEPSize(Type *ElementType){
  switch(ElementType->getTypeID()){
  case Type::IntegerTyID:
  case Type::DoubleTyID:
  case Type::FloatTyID:
  case Type::PointerTyID:
    {
      SizeVector.push_back(1);
      return ;
    }
  case Type::ArrayTyID:
    {
      SizeVector.push_back(CalcAggregateTypeSize(ElementType));
      ArrayType *SubArray = dyn_cast<ArrayType>(ElementType);
      CalcGEPSize(SubArray->getArrayElementType());
      return ;
    }
  case Type::StructTyID:
  default:
    {
      cerr<<"GEPExecute::CalcGEPSize This Operation is not defined"<<endl;
      exit(1);
    }
  }
}


/*�o�O���܂񂾎���
 *���d�z���\���̂̃A�h���X�v�Z�̃A���S���Y�����s���S
 */
unique_ptr<IMAWB>GEPExecute::Execute(){
  unsigned Address = 0;
  SizeVector.push_back(0);
  SizeVector.push_back(1);
  Type *ElementType =dyn_cast<PointerType>( _GetElementPtrInst->getPointerOperandType())->getElementType();
  switch(ElementType->getTypeID()){
  case Type::ArrayTyID:
    {
      CalcGEPSize(ElementType);
      for(unsigned i = 1;i < NumOperands;++i)
	{
	  //cerr<<SizeVector[i]<<"*"<<Operands[i]->getInt()<<endl;
	  Address += SizeVector[i] * Operands[i]->getInt();
	}
      cerr<<endl;
      break;
    }
  case Type::StructTyID:
    {
      CalcGEPSize(ElementType);
      cerr<<"SizeVector.size() = "<<SizeVector.size()<<endl;
      for(unsigned i = 1;i < SizeVector.size();++i)
	{
	  cerr<<SizeVector[i]<<endl;
	}
      cerr<<"GEPExecute::Execute This Operation is not defined"<<endl;
      return unique_ptr<IMAWB>(new ErrorExit);
    }
  case Type::IntegerTyID:
  case Type::DoubleTyID:
  case Type::FloatTyID:
  case Type::PointerTyID:
    {
      Address = Operands[1]->getUnsigned()+Operands[2]->getInt();
      break;
    }
  case Type::VectorTyID:
  default:
    {
      cerr<<"GEPExecute::Execute This Operation is not defined. TypeID = "<<ElementType->getTypeID()<<endl;
      return unique_ptr<IMAWB>(new ErrorExit);
    }
  }
  IMAWB *NewIMAWB = new GEPMAWB(Address,Operands[0]->getName());
  return unique_ptr<IMAWB>(NewIMAWB);
}

RunInstResult GEPMAWB::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->setRegAdd(Address,WBRegisterName)->setTrace();
  RunInstResult MAWBRtn;
  return MAWBRtn;
}

//unsigned GEPOpExecute()
