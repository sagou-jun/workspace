#ifndef MEMORYOP_H
#define MEMORYOP_H

#include"IRSimExe.hpp"
#include"IRSimMems.hpp"
#include"IRSimRegs.hpp"

namespace IRSIM{

  class AllocaExecute:public Execution{
  private:
    SIMMemAllocator *_MemAllocator;
    AllocaExecute(const AllocaExecute &obj);
    operator=(const AllocaExecute &obj);
  public:
    AllocaExecute(SIMMemAllocator *MemAllocator):_MemAllocator(MemAllocator){};
    ~AllocaExecute(){};
    unique_ptr<IMAWB> Execute();
  };
  
  class AllocaMAWB : public IMAWB{
  private:
    unsigned AllocatedAddress;
    string WBRegisterName;
    AllocaMAWB(const AllocaMAWB &obj);
    operator=(const AllocaMAWB &obj);
  public:
    AllocaMAWB(unsigned addr,string RegisterName):AllocatedAddress(addr),WBRegisterName(RegisterName){};
    ~AllocaMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem){RegT->setRegAdd(AllocatedAddress,WBRegisterName);};
  };

  class StoreExecute:public Execution{
  private:
    StoreExecute(const StoreExecute &obj);
    operator=(const StoreExecute &obj);
  public:
    StoreExecute(){};
    ~StoreExecute(){};
    unique_ptr<IMAWB>Execute();
  };

  class StoreGEPOPExecute:public Execution{
  };
  
  template<typename t>
  class StoreMAWB:public IMAWB{
  private:
    unsigned Address;
    t _Value;
    StoreMAWB(const StoreMAWB &obj);
    operator=(const StoreMAWB &obj);
  public:
    StoreMAWB(unsigned addr,t value):Address(addr),_Value(value){};
    ~StoreMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem){};
  };

  template<>
  RunInstResult StoreMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult StoreMAWB<char>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult StoreMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult StoreMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem);

  class LoadExecute:public Execution{
  private:
  public:
    LoadExecute(){};
    ~LoadExecute(){};
    unique_ptr<IMAWB>Execute();
  };

  template<typename t>
  class LoadMAWB:public IMAWB{
  private:
    string RegisterName;
    t Address;
    bool Trace;
    LoadMAWB(const LoadMAWB &obj);
    operator=(const LoadMAWB &obj);
  public:
    LoadMAWB(string Name,t addr,bool trace=false):RegisterName(Name),Address(addr),Trace(trace){};
    ~LoadMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem){};
  };

  template<>
  RunInstResult LoadMAWB<int>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult LoadMAWB<char>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult LoadMAWB<double>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult LoadMAWB<unsigned>::Execute(RegTable *RegT,SIMMem *Mem);

  class GEPExecute:public Execution{
  private:
    GetElementPtrInst *_GetElementPtrInst;
    vector<unsigned> SizeVector;
    GEPExecute(const GEPExecute &obj);
    operator=(const GEPExecute &obj);
  public:
    GEPExecute(GetElementPtrInst *getelementptrinst):_GetElementPtrInst(getelementptrinst){};
    ~GEPExecute(){};
    void CalcGEPSize(Type *ElementType);
    unique_ptr<IMAWB>Execute();
  };

  class GEPMAWB:public IMAWB{
  private:
    unsigned Address;
    string WBRegisterName;
    GEPMAWB(const GEPMAWB &obj);
    operator=(const GEPMAWB &obj);
  public:
    GEPMAWB(unsigned address,string RegisterName):Address(address),WBRegisterName(RegisterName){};
    ~GEPMAWB(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };
  
}

#endif
