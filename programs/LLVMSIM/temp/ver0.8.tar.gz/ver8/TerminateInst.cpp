#include"TerminateInst.hpp"

using namespace IRSIM;

unique_ptr<IMAWB> BranchExecute::Execute(){
  if(_BranchInst->isUnconditional())
    {
      unique_ptr<IMAWB> rtn(new BranchTerminate(_BranchInst->getSuccessor(0)));
      return rtn;
    }
  else if(_BranchInst->isConditional())
    {
      if(Operands[0]->getInt() == 0)
	{
	  unique_ptr<IMAWB> rtn(new BranchTerminate(_BranchInst->getSuccessor(1)));
	  return rtn;
	}
      else
	{
	  unique_ptr<IMAWB> rtn(new BranchTerminate(_BranchInst->getSuccessor(0)));
	  return rtn;
	}
    }
}

RunInstResult BranchTerminate::Execute(RegTable *RegT,SIMMem *Mem){
  RunInstResult rtn(BRANCH_RUNINST);
  rtn.NextBB = NextBasicBlock;
  return rtn;
}

unique_ptr<IMAWB> ReturnExecute::Execute(){
  //main�֐����邢�͖߂�l��void�^�̏ꍇ
  if(PtrFunctionStack->empty()||NumOperands == 0)
    {
      unique_ptr<IMAWB> rtn(new ReturnTerminateVoid());
      return rtn;
    }
  unsigned RXRegID = PtrFunctionStack->back()->RegID;
  IMAWB *NewIMAWB;

  
  if(Operands[0]->isImmediate())
    {
      switch(Operands[0]->getType().getTypeID()){
      case IRSimTypes::INTEGER:
	NewIMAWB = new ReturnTerminateImmediate<int>(Operands[0]->getInt(),RXRegID);
	break;
      case IRSimTypes::CHAR:
	NewIMAWB = new ReturnTerminateImmediate<char>(Operands[0]->getChar(),RXRegID);
	break;
      case IRSimTypes::DOUBLE:
	NewIMAWB = new ReturnTerminateImmediate<double>(Operands[0]->getDouble(),RXRegID);
	break;
      default:
	cerr<<"ReturnExecute::Execute Undefine Operation (Return Immediate Value)"<<endl;
	exit(1);
      }
    }
  else
    NewIMAWB = new ReturnTerminate(Operands[0]->getName(),RXRegID);

  unique_ptr<IMAWB> rtn(NewIMAWB);
  return rtn;
}

RunInstResult ReturnTerminate::Execute(RegTable *RegT,SIMMem *Mem){
  RegT->ReturnValue(_TXRegisterName,_RXRegisterID);
  RunInstResult rtn;
  rtn.Result = RETURN_RUNINST;
  return rtn;
}

template<>
RunInstResult ReturnTerminateImmediate<int>::Execute(RegTable *RegT,SIMMem *Mem){
  ImmediateValue<int> Imm(_ReturnValue);
  RegT->ReturnValue(&Imm,_RXRegisterID);
  RunInstResult rtn;
  rtn.Result = RETURN_RUNINST;
  return rtn;
}

template<>
RunInstResult ReturnTerminateImmediate<char>::Execute(RegTable *RegT,SIMMem *Mem){
  ImmediateValue<int> Imm(_ReturnValue);
  RegT->ReturnValue(&Imm,_RXRegisterID);
  RunInstResult rtn;
  rtn.Result = RETURN_RUNINST;
  return rtn;
}

template<>
RunInstResult ReturnTerminateImmediate<double>::Execute(RegTable *RegT,SIMMem *Mem){
  ImmediateValue<int> Imm(_ReturnValue);
  RegT->ReturnValue(&Imm,_RXRegisterID);
  RunInstResult rtn;
  rtn.Result = RETURN_RUNINST;
  return rtn;
}

unique_ptr<IMAWB> CallExecute::Execute(){
  Function *CalledFunction = _CallInst->getCalledFunction();
  FunctionType *FnType = CalledFunction->getFunctionType();
  if(CalledFunction->isDeclaration())
    {
      cerr<<"This Function is only declaration \""<<CalledFunction->getName().str()<<"\""<<endl;
      //�f�o�b�O���₷�����邽�ߖ߂�l��void�^�̏ꍇ�͂��̂܂܎��s
      if((FnType->getReturnType()->getTypeID() != Type::VoidTyID)&&(CalledFunction->getName().str()!="printf"))
	{
	  unique_ptr<IMAWB> rtn(new ErrorExit());
	  return rtn;
	}
      else
	{
	  cerr<<"Ignore Function Calling "<<CalledFunction->getName().str()<<endl;
	  unique_ptr<IMAWB> rtn(new DoNothing());
	  return rtn;
	}
    }
  Operands.dump();
  exit(1);
}

RunInstResult CallTerminate::Execute(RegTable *RegT,SIMMem *Mem){
}
