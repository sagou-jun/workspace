#ifndef TERMINATEINST_H
#define TERMINATEINST_H

#include"IRSimExe.hpp"

namespace IRSIM{

  class BranchExecute:public Execution{
  private:
    BranchInst *_BranchInst;
    BranchExecute(const BranchExecute &obj);
    operator=(const BranchExecute &obj);
  public:
    BranchExecute(BranchInst *Inst):_BranchInst(Inst){};
    ~BranchExecute(){};
    unique_ptr<IMAWB> Execute();
  };

  class BranchTerminate:public IMAWB{
  private:
    BasicBlock *NextBasicBlock;
    BranchTerminate(const BranchTerminate &obj);
    operator=(const BranchTerminate &obj);
  public:
    BranchTerminate(BasicBlock *next):NextBasicBlock(next){};
    ~BranchTerminate(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };

  class ReturnExecute:public Execution{
  private:
    ReturnInst *_ReturnInst;
    Stack<StackELE> *PtrFunctionStack;
    ReturnExecute(const ReturnExecute &obj);
    operator=(const ReturnExecute &obj);
  public:
    ReturnExecute(ReturnInst *Inst,Stack<StackELE> *stack):_ReturnInst(Inst),PtrFunctionStack(stack){};
    ~ReturnExecute(){};
    unique_ptr<IMAWB> Execute();
  };

  /*�߂�l�����W�X�^�̏ꍇ*/
  class ReturnTerminate:public IMAWB{
  private:
    string _TXRegisterName;
    unsigned _RXRegisterID;
    ReturnTerminate(const ReturnTerminate &obj);
    operator=(const ReturnTerminate &obj);
  public:
    ReturnTerminate(string TXRegisterName, unsigned RXRegisterID):_TXRegisterName(TXRegisterName),_RXRegisterID(RXRegisterID){};
    ~ReturnTerminate(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };

  /*�߂�l�����l�̏ꍇ*/
  template<typename t>
  class ReturnTerminateImmediate:public IMAWB{
    t _ReturnValue;
    unsigned _RXRegisterID;
    ReturnTerminateImmediate(const ReturnTerminateImmediate &obj);
    operator=(const ReturnTerminateImmediate &obj);
  public:
    ReturnTerminateImmediate(t ReturnValue, unsigned RXRegisterID):_ReturnValue(ReturnValue),_RXRegisterID(RXRegisterID){};
    ~ReturnTerminateImmediate(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };

  /*���l�Ń������A�h���X���w�肷�邱�Ƃ͂Ȃ��̂�unsigned�^�̓��ꉻ�֐��͗p�ӂ��Ȃ�*/
  template<>
  RunInstResult ReturnTerminateImmediate<int>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult ReturnTerminateImmediate<char>::Execute(RegTable *RegT,SIMMem *Mem);
  template<>
  RunInstResult ReturnTerminateImmediate<double>::Execute(RegTable *RegT,SIMMem *Mem);
  
  /*�߂�l��void�̏ꍇ*/
  class ReturnTerminateVoid:public IMAWB{
  private:
    ReturnTerminateVoid(const ReturnTerminateVoid &obj);
    operator=(const ReturnTerminateVoid &obj);
  public:
    ReturnTerminateVoid(){};
    ~ReturnTerminateVoid(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem)
    {
      RunInstResult rtn;
      rtn.Result = RunInstResultCode::RETURN_RUNINST;
      return rtn;
    };
  };

  
  
  class CallExecute:public Execution{
  private:
    CallInst *_CallInst;
    Stack<StackELE> *PtrFunctionStack;
    CallExecute(const CallExecute &obj);
    operator=(const CallExecute &obj);
  public:
    CallExecute(CallInst *Inst,Stack<StackELE> *stack):_CallInst(Inst),PtrFunctionStack(stack){};
    ~CallExecute(){};
    unique_ptr<IMAWB> Execute();
  };

  
  class CallTerminate:public IMAWB{
  private:
    Function *CalledFunction;
    CallTerminate(const CallTerminate &obj);
    operator=(const CallTerminate &obj);
  public:
    CallTerminate(Function *func):CalledFunction(func){};
    ~CallTerminate(){};
    RunInstResult Execute(RegTable *RegT,SIMMem *Mem);
  };
  
}
#endif
